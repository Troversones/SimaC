#include <stdio.h>
#include <string.h>

#define MAX_CSIGAK 10

typedef struct {
    char nev[20];
    unsigned sebesseg;
    unsigned meret;
} Csiga;

typedef struct {
    unsigned meret;
    Csiga csigak[MAX_CSIGAK];
    unsigned csigak_szama;
} Kert;

void csigat_kiir(Csiga csiga) {
    printf("%s csiga sebessege %u, merete %u.\n", csiga.nev, csiga.sebesseg, csiga.meret);
}

void kertet_kiir(Kert kert) {
    printf("A kert alapterulete: %u\n", kert.meret);
    printf("A kertben levo csigak (%u db):\n", kert.csigak_szama);
    for (int i = 0; i < kert.csigak_szama; i++) {
        printf("  ");
        csigat_kiir(kert.csigak[i]);
    }
}

Csiga csigat_keszit(char nev[], unsigned sebesseg, unsigned meret) {
    Csiga csiga;
    strcpy(csiga.nev, nev);
    csiga.sebesseg = sebesseg;
    csiga.meret = meret;
    return csiga;
}

Kert kertet_keszit(unsigned meret) {
    Kert kert;
    kert.meret = meret;
    kert.csigak_szama = 0;
    return kert;
}

Csiga leggyorsabb(Kert kert) {
    Csiga max = kert.csigak[0];

    for (int i = 1; i < kert.csigak_szama; i++) {
        if (kert.csigak[i].sebesseg > max.sebesseg) {
            max = kert.csigak[i];
        }
    }

    return max;
}

Kert csigat_hozzaad(Kert kert, Csiga csiga) {
    if (kert.csigak_szama == MAX_CSIGAK) {
        return kert;
    }

    kert.csigak[kert.csigak_szama] = csiga;
    kert.csigak_szama++;
    return kert;
}

int main() {
    Csiga cs1 = csigat_keszit("Antal", 11, 20);
    Csiga cs2 = csigat_keszit("Gabor", 10, 5);
    Csiga cs3 = csigat_keszit("David", 7, 8);

    Kert kert = kertet_keszit(11);
    kert = csigat_hozzaad(kert, cs1);
    kert = csigat_hozzaad(kert, cs2);
    kert = csigat_hozzaad(kert, cs3);

    kertet_kiir(kert);

    printf("A leggyorsabb csiga: %s\n", leggyorsabb(kert).nev);

    return 0;
}
