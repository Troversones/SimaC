#include <stdio.h>
#include <string.h>

int main() {
    // szoveg hossza
    char cica[] = "Cica";
    printf("A cica hossza: %d\n", strlen(cica));

    printf("---------------------------------------------\n");

    // szovegek masolasa
    char tehen[20];
    printf("A szoveg kezdetben: %s\n", tehen);
    strcpy(tehen, "TEHENECSKE");
    printf("A szoveg masolas utan: %s\n", tehen);

    printf("---------------------------------------------\n");

    // szovegek osszefuzese
    strcat(tehen, " elrepul");
    printf("A szoveg hozzafuzes utan: %s\n", tehen);

    printf("---------------------------------------------\n");

    // szovegek osszehasonlitasa
    char s1[] = "macska";
    char s2[] = "cica";
    char s3[] = "macskak";
    printf("osszehasonlitas s1, s2: %d\n", strcmp(s1, s2));
    printf("osszehasonlitas s2, s1: %d\n", strcmp(s2, s1));
    printf("osszehasonlitas s1, s1: %d\n", strcmp(s1, s1));
    printf("osszehasonlitas s1, s3: %d\n", strcmp(s1, s3));

    printf("---------------------------------------------\n");

    // kereses stringben
    char szoveg[] = "ket macska";
    printf("A '%s' szoveg az elso 'a'-tol kezdodoen: %s\n", szoveg, strchr(szoveg, 'a'));

    char szoveg2[] = "ket macska ul itt";
    char keresendo[] = "csk";
    char random[] = "anvjkasv";
    printf("A '%s' szoveg az elso '%s' elofordulasatol kezdodoen: %s\n", szoveg2, keresendo, strstr(szoveg2, keresendo));
    printf("Ha nem fordul benne elo: %s\n", strstr(szoveg2, random));

    return 0;
}
