#include <stdio.h>
#include <string.h>

typedef struct {
    char nev[20];
    unsigned sebesseg;
    unsigned meret;
} Csiga;

void csigat_kiir(Csiga csiga) {
    printf("%s csiga sebessege %u, merete %u.\n", csiga.nev, csiga.sebesseg, csiga.meret);
}

Csiga csigat_keszit(char nev[], unsigned sebesseg, unsigned meret) {
    Csiga csiga;
    strcpy(csiga.nev, nev);
    csiga.sebesseg = sebesseg;
    csiga.meret = meret;
    return csiga;
}

Csiga gyorsabb(Csiga cs1, Csiga cs2) {
    if (cs1.sebesseg > cs2.sebesseg) {
        return cs1;
    }

    return cs2;
}

int main() {
    Csiga cs1 = csigat_keszit("Antal", 11, 20);
    Csiga cs2 = csigat_keszit("Gabor", 10, 5);
    Csiga cs3 = csigat_keszit("David", 7, 8);

    csigat_kiir(cs1);
    csigat_kiir(cs2);
    csigat_kiir(cs3);

    printf("---------------------------------------------\n");

    printf("A cs1-cs2 kozul a leggyorsabb csiga: %s\n", gyorsabb(cs1, cs2).nev);
    printf("A cs2-cs3 kozul a leggyorsabb csiga: %s\n", gyorsabb(cs2, cs3).nev);

    return 0;
}